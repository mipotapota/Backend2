package cs.dit.mapper;

import java.util.List;
import java.util.Map;
import cs.dit.domain.ReplyVO;

public interface ReplyMapper {
    // 댓글 목록 조회 (특정 게시판의 특정 게시글)
    public List<ReplyVO> getList(Map<String, Object> params);
    
    // 댓글 조회
    public ReplyVO read(Long rno);
    
    // 댓글 등록
    public int insert(ReplyVO reply);
    
    // 댓글 수정
    public int update(ReplyVO reply);
    
    // 댓글 삭제
    public int delete(Long rno);
    
    // 특정 게시글의 댓글 수 카운트
    public int getCount(Map<String, Object> params);
}
