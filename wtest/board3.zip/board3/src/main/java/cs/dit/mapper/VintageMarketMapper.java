package cs.dit.mapper;

import java.util.List;
import cs.dit.domain.VintageMarketVO;

public interface VintageMarketMapper {
    // 전체 목록
    public List<VintageMarketVO> getList();
    
    // 검색/필터
    public List<VintageMarketVO> getListByTradeType(String tradeType);
    public List<VintageMarketVO> getListByBrand(String brand);
    public List<VintageMarketVO> getListByStatus(String tradeStatus);
    
    // 조회
    public VintageMarketVO read(Long bno);
    
    // 등록
    public int insert(VintageMarketVO board);
    
    // 수정
    public int update(VintageMarketVO board);
    
    // 삭제
    public int delete(Long bno);
    
    // 조회수 증가
    public void increaseViewCount(Long bno);
    
    // 좋아요 증가/감소
    public void increaseLikeCount(Long bno);
    public void decreaseLikeCount(Long bno);
    
    // 댓글 수 업데이트
    public void updateReplyCount(Long bno);
}
