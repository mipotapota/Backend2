package cs.dit.service;

import java.util.List;
import cs.dit.domain.ReplyVO;

public interface ReplyService {
    public List<ReplyVO> getList(String boardType, Long bno);
    public ReplyVO get(Long rno);
    public int register(ReplyVO reply);
    public int modify(ReplyVO reply);
    public int remove(Long rno);
    public int getCount(String boardType, Long bno);
}
