package cs.dit.mapper;

import java.util.List;

import cs.dit.domain.BoardVO;

public interface BoardMapper {
	
	//게시글 목록 조회하기
	public List<BoardVO> getList();
	
	//선택된 한개의 게시글 조회하기
	public BoardVO read(Long bno);
	
	//한개의 게시글 등록하기
	public int insert(BoardVO board);
	
	public int update(BoardVO board);
	
	public int delete(Long bno);

}
