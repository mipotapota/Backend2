package cs.dit.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cs.dit.domain.VintageMarketVO;
import cs.dit.mapper.VintageMarketMapper;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class VintageMarketServiceImpl implements VintageMarketService {
    
    @Autowired
    private VintageMarketMapper mapper;
    
    @Override
    public List<VintageMarketVO> getList() {
        return mapper.getList();
    }
    
    @Override
    public List<VintageMarketVO> getListByTradeType(String tradeType) {
        return mapper.getListByTradeType(tradeType);
    }
    
    @Override
    public List<VintageMarketVO> getListByBrand(String brand) {
        return mapper.getListByBrand(brand);
    }
    
    @Override
    public List<VintageMarketVO> getListByStatus(String tradeStatus) {
        return mapper.getListByStatus(tradeStatus);
    }
    
    @Override
    public VintageMarketVO get(Long bno) {
        return mapper.read(bno);
    }
    
    @Override
    public int register(VintageMarketVO board) {
        return mapper.insert(board);
    }
    
    @Override
    public int modify(VintageMarketVO board) {
        return mapper.update(board);
    }
    
    @Override
    public int remove(Long bno) {
        return mapper.delete(bno);
    }
    
    @Override
    public void increaseViewCount(Long bno) {
        mapper.increaseViewCount(bno);
    }
    
    @Override
    public void increaseLikeCount(Long bno) {
        mapper.increaseLikeCount(bno);
    }
    
    @Override
    public void decreaseLikeCount(Long bno) {
        mapper.decreaseLikeCount(bno);
    }
}
