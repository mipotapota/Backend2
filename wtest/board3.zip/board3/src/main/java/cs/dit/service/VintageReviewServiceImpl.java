package cs.dit.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cs.dit.domain.VintageReviewVO;
import cs.dit.mapper.VintageReviewMapper;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class VintageReviewServiceImpl implements VintageReviewService {
    
    @Autowired
    private VintageReviewMapper mapper;
    
    @Override
    public List<VintageReviewVO> getList() {
        log.info("getList...........");
        return mapper.getList();
    }
    
    @Override
    public List<VintageReviewVO> getListByBrand(String brand) {
        return mapper.getListByBrand(brand);
    }
    
    @Override
    public List<VintageReviewVO> getListByRating(int rating) {
        return mapper.getListByRating(rating);
    }
    
    @Override
    public VintageReviewVO get(Long bno) {
        log.info("get............" + bno);
        return mapper.read(bno);
    }
    
    @Override
    public int register(VintageReviewVO board) {
        log.info("register..........." + board);
        return mapper.insert(board);
    }
    
    @Override
    public int modify(VintageReviewVO board) {
        log.info("modify..........." + board);
        return mapper.update(board);
    }
    
    @Override
    public int remove(Long bno) {
        log.info("remove..........." + bno);
        return mapper.delete(bno);
    }
    
    @Override
    public void increaseViewCount(Long bno) {
        mapper.increaseViewCount(bno);
    }
    
    @Override
    public void increaseLikeCount(Long bno) {
        mapper.increaseLikeCount(bno);
    }
    
    @Override
    public void decreaseLikeCount(Long bno) {
        mapper.decreaseLikeCount(bno);
    }
}
