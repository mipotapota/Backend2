package cs.dit.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import cs.dit.domain.VintageReviewVO;
import cs.dit.service.VintageReviewService;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/review/*")
public class VintageReviewController {
    
    @Autowired
    private VintageReviewService service;
    
    // ��ü ���
    @GetMapping("/list")
    public void list(Model model) {
        log.info("Review List--------------------------");
        List<VintageReviewVO> list = service.getList();
        model.addAttribute("list", list);
    }
    
    // �׽�Ʈ�� ���
    @GetMapping("/test")
    public void test(Model model) {
        log.info("Review Test--------------------------");
        List<VintageReviewVO> list = service.getList();
        log.info("List size: " + list.size());
        model.addAttribute("list", list);
    }
    
    // �귣�庰 ���
    @GetMapping("/listByBrand")
    public String listByBrand(@RequestParam("brand") String brand, Model model) {
        List<VintageReviewVO> list = service.getListByBrand(brand);
        model.addAttribute("list", list);
        model.addAttribute("filterType", "brand");
        model.addAttribute("filterValue", brand);
        return "/review/list";
    }
    
    // ������ ���
    @GetMapping("/listByRating")
    public String listByRating(@RequestParam("rating") int rating, Model model) {
        List<VintageReviewVO> list = service.getListByRating(rating);
        model.addAttribute("list", list);
        model.addAttribute("filterType", "rating");
        model.addAttribute("filterValue", rating);
        return "/review/list";
    }

    // ��ȸ (��ȸ�� ����)
    @GetMapping({"/get", "/modify"})
    public void get(@RequestParam("bno") Long bno, Model model) {
        log.info("Review get--------------------------");
        
        // ��ȸ�� ����
        service.increaseViewCount(bno);
        
        VintageReviewVO review = service.get(bno);
        model.addAttribute("review", review);
    }
    
    // �Է�ȭ�� ���
    @GetMapping("/register")
    public void register() {
        
    }
    
    // DB�� �Խñ� �Է�
    @PostMapping("/register")
    public String register(VintageReviewVO board, RedirectAttributes rttr) {
        int count = service.register(board);
        
        if(count == 1) {
            rttr.addFlashAttribute("result", "registered");
        }
    
        return "redirect:/review/list";
    }
    
    // ����
    @PostMapping("/modify")
    public String modify(VintageReviewVO board, RedirectAttributes rttr) {
        log.info("Review modify------------------------------");
        int count = service.modify(board);
        
        if(count == 1)
            rttr.addFlashAttribute("result", "modified");
        
        return "redirect:/review/list";
    }	
    
    // ����
    @PostMapping("/remove")
    public String remove(Long bno) {
        log.info("Review remove------------------------------");
        service.remove(bno);
        
        return "redirect:/review/list";
    }
    
    // ���ƿ� ��� (AJAX)
    @PostMapping("/like")
    @ResponseBody
    public int toggleLike(@RequestParam("bno") Long bno, @RequestParam("isLiked") boolean isLiked) {
        if (isLiked) {
            // ���ƿ� ��� (����)
            service.decreaseLikeCount(bno);
        } else {
            // ���ƿ� �߰� (����)
            service.increaseLikeCount(bno);
        }
        VintageReviewVO review = service.get(bno);
        return review.getLikeCount();
    }
}
