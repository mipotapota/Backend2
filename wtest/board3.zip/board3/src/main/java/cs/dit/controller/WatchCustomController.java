package cs.dit.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import cs.dit.domain.WatchCustomVO;
import cs.dit.service.WatchCustomService;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/custom/*")
public class WatchCustomController {
    
    @Autowired
    private WatchCustomService service;
    
    @GetMapping("/list")
    public void list(Model model) {
        log.info("Custom List--------------------------");
        List<WatchCustomVO> list = service.getList();
        model.addAttribute("list", list);
    }
    
    @GetMapping("/listByDifficulty")
    public String listByDifficulty(@RequestParam("difficulty") String difficulty, Model model) {
        List<WatchCustomVO> list = service.getListByDifficulty(difficulty);
        model.addAttribute("list", list);
        model.addAttribute("filterType", "difficulty");
        model.addAttribute("filterValue", difficulty);
        return "/custom/list";
    }

    @GetMapping({"/get", "/modify"})
    public void get(@RequestParam("bno") Long bno, Model model) {
        log.info("Custom get--------------------------");
        service.increaseViewCount(bno);
        WatchCustomVO custom = service.get(bno);
        model.addAttribute("custom", custom);
    }
    
    @GetMapping("/register")
    public void register() {
        
    }
    
    @PostMapping("/register")
    public String register(WatchCustomVO board, RedirectAttributes rttr) {
        int count = service.register(board);
        
        if(count == 1) {
            rttr.addFlashAttribute("result", "registered");
        }
    
        return "redirect:/custom/list";
    }
    
    @PostMapping("/modify")
    public String modify(WatchCustomVO board, RedirectAttributes rttr) {
        log.info("Custom modify------------------------------");
        int count = service.modify(board);
        
        if(count == 1)
            rttr.addFlashAttribute("result", "modified");
        
        return "redirect:/custom/list";
    }	
    
    @PostMapping("/remove")
    public String remove(Long bno) {
        log.info("Custom remove------------------------------");
        service.remove(bno);
        
        return "redirect:/custom/list";
    }
    
    @PostMapping("/like")
    @ResponseBody
    public int toggleLike(@RequestParam("bno") Long bno, @RequestParam("isLiked") boolean isLiked) {
        if (isLiked) {
            service.decreaseLikeCount(bno);
        } else {
            service.increaseLikeCount(bno);
        }
        WatchCustomVO custom = service.get(bno);
        return custom.getLikeCount();
    }
}
