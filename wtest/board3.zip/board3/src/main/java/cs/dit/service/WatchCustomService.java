package cs.dit.service;

import java.util.List;
import cs.dit.domain.WatchCustomVO;

public interface WatchCustomService {
    public List<WatchCustomVO> getList();
    public List<WatchCustomVO> getListByDifficulty(String difficulty);
    public List<WatchCustomVO> getListByMovement(String movement);
    public WatchCustomVO get(Long bno);
    public int register(WatchCustomVO board);
    public int modify(WatchCustomVO board);
    public int remove(Long bno);
    public void increaseViewCount(Long bno);
    public void increaseLikeCount(Long bno);
    public void decreaseLikeCount(Long bno);
}
