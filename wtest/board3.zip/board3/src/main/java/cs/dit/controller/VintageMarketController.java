package cs.dit.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import cs.dit.domain.VintageMarketVO;
import cs.dit.service.VintageMarketService;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/market/*")
public class VintageMarketController {
    
    @Autowired
    private VintageMarketService service;
    
    @GetMapping("/list")
    public void list(Model model) {
        log.info("Market List--------------------------");
        List<VintageMarketVO> list = service.getList();
        model.addAttribute("list", list);
    }
    
    @GetMapping("/listByType")
    public String listByType(@RequestParam("type") String type, Model model) {
        List<VintageMarketVO> list = service.getListByTradeType(type);
        model.addAttribute("list", list);
        model.addAttribute("filterType", "type");
        model.addAttribute("filterValue", type);
        return "/market/list";
    }
    
    @GetMapping("/listByStatus")
    public String listByStatus(@RequestParam("status") String status, Model model) {
        List<VintageMarketVO> list = service.getListByStatus(status);
        model.addAttribute("list", list);
        model.addAttribute("filterType", "status");
        model.addAttribute("filterValue", status);
        return "/market/list";
    }

    @GetMapping({"/get", "/modify"})
    public void get(@RequestParam("bno") Long bno, Model model) {
        log.info("Market get--------------------------");
        service.increaseViewCount(bno);
        VintageMarketVO market = service.get(bno);
        model.addAttribute("market", market);
    }
    
    @GetMapping("/register")
    public void register() {
        
    }
    
    @PostMapping("/register")
    public String register(VintageMarketVO board, RedirectAttributes rttr) {
        int count = service.register(board);
        
        if(count == 1) {
            rttr.addFlashAttribute("result", "registered");
        }
    
        return "redirect:/market/list";
    }
    
    @PostMapping("/modify")
    public String modify(VintageMarketVO board, RedirectAttributes rttr) {
        log.info("Market modify------------------------------");
        int count = service.modify(board);
        
        if(count == 1)
            rttr.addFlashAttribute("result", "modified");
        
        return "redirect:/market/list";
    }	
    
    @PostMapping("/remove")
    public String remove(Long bno) {
        log.info("Market remove------------------------------");
        service.remove(bno);
        
        return "redirect:/market/list";
    }
    
    @PostMapping("/like")
    @ResponseBody
    public int toggleLike(@RequestParam("bno") Long bno, @RequestParam("isLiked") boolean isLiked) {
        if (isLiked) {
            service.decreaseLikeCount(bno);
        } else {
            service.increaseLikeCount(bno);
        }
        VintageMarketVO market = service.get(bno);
        return market.getLikeCount();
    }
}
