package cs.dit.mapper;

import java.util.List;
import cs.dit.domain.WatchCustomVO;

public interface WatchCustomMapper {
    // 전체 목록
    public List<WatchCustomVO> getList();
    
    // 검색/필터
    public List<WatchCustomVO> getListByDifficulty(String difficulty);
    public List<WatchCustomVO> getListByMovement(String movement);
    
    // 조회
    public WatchCustomVO read(Long bno);
    
    // 등록
    public int insert(WatchCustomVO board);
    
    // 수정
    public int update(WatchCustomVO board);
    
    // 삭제
    public int delete(Long bno);
    
    // 조회수 증가
    public void increaseViewCount(Long bno);
    
    // 좋아요 증가/감소
    public void increaseLikeCount(Long bno);
    public void decreaseLikeCount(Long bno);
    
    // 댓글 수 업데이트
    public void updateReplyCount(Long bno);
}
