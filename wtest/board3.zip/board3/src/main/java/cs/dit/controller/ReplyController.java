package cs.dit.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import cs.dit.domain.ReplyVO;
import cs.dit.service.ReplyService;
import lombok.extern.log4j.Log4j;

@RestController
@Log4j
@RequestMapping("/replies/*")
public class ReplyController {
    
    @Autowired
    private ReplyService service;
    
    // 댓글 목록 조회
    @GetMapping("/{boardType}/{bno}")
    public ResponseEntity<List<ReplyVO>> getList(
            @PathVariable("boardType") String boardType,
            @PathVariable("bno") Long bno) {
        
        log.info("getList - boardType: " + boardType + ", bno: " + bno);
        List<ReplyVO> list = service.getList(boardType, bno);
        return new ResponseEntity<>(list, HttpStatus.OK);
    }
    
    // 댓글 등록
    @PostMapping("/new")
    public ResponseEntity<String> create(@RequestBody ReplyVO reply) {
        log.info("create reply: " + reply);
        int result = service.register(reply);
        
        return result == 1 
            ? new ResponseEntity<>("success", HttpStatus.OK)
            : new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    // 댓글 조회
    @GetMapping("/{rno}")
    public ResponseEntity<ReplyVO> get(@PathVariable("rno") Long rno) {
        log.info("get reply: " + rno);
        ReplyVO reply = service.get(rno);
        
        return new ResponseEntity<>(reply, HttpStatus.OK);
    }
    
    // 댓글 수정
    @PutMapping("/{rno}")
    public ResponseEntity<String> modify(
            @PathVariable("rno") Long rno,
            @RequestBody ReplyVO reply) {
        
        reply.setRno(rno);
        log.info("modify reply: " + reply);
        int result = service.modify(reply);
        
        return result == 1 
            ? new ResponseEntity<>("success", HttpStatus.OK)
            : new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    // 댓글 삭제
    @DeleteMapping("/{rno}")
    public ResponseEntity<String> remove(@PathVariable("rno") Long rno) {
        log.info("remove reply: " + rno);
        int result = service.remove(rno);
        
        return result == 1 
            ? new ResponseEntity<>("success", HttpStatus.OK)
            : new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
