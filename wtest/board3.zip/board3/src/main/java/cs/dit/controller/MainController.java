package cs.dit.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import cs.dit.domain.VintageReviewVO;
import cs.dit.domain.VintageMarketVO;
import cs.dit.domain.WatchCustomVO;
import cs.dit.service.VintageReviewService;
import cs.dit.service.VintageMarketService;
import cs.dit.service.WatchCustomService;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
public class MainController {
    
    @Autowired
    private VintageReviewService reviewService;
    
    @Autowired
    private VintageMarketService marketService;
    
    @Autowired
    private WatchCustomService customService;
    
    @GetMapping("/")
    public String home(Model model) {
        log.info("Main page--------------------------");
        
        // 각 게시판별 최신 3개 글 가져오기
        List<VintageReviewVO> reviewList = reviewService.getList();
        List<VintageMarketVO> marketList = marketService.getList();
        List<WatchCustomVO> customList = customService.getList();
        
        // 최신 3개만
        if(reviewList.size() > 3) {
            reviewList = reviewList.subList(0, 3);
        }
        if(marketList.size() > 3) {
            marketList = marketList.subList(0, 3);
        }
        if(customList.size() > 3) {
            customList = customList.subList(0, 3);
        }
        
        model.addAttribute("reviewList", reviewList);
        model.addAttribute("marketList", marketList);
        model.addAttribute("customList", customList);
        
        return "home";
    }
}
