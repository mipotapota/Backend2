package cs.dit.service;

import java.util.List;
import cs.dit.domain.VintageReviewVO;

public interface VintageReviewService {
    public List<VintageReviewVO> getList();
    public List<VintageReviewVO> getListByBrand(String brand);
    public List<VintageReviewVO> getListByRating(int rating);
    public VintageReviewVO get(Long bno);
    public int register(VintageReviewVO board);
    public int modify(VintageReviewVO board);
    public int remove(Long bno);
    public void increaseViewCount(Long bno);
    public void increaseLikeCount(Long bno);
    public void decreaseLikeCount(Long bno);
}
