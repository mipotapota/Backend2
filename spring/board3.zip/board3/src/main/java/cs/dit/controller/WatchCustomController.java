package cs.dit.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import cs.dit.domain.WatchCustomVO;
import cs.dit.service.WatchCustomService;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/custom/*")
@Log4j
public class WatchCustomController {
    
    @Autowired
    private WatchCustomService service;
    
    private static final String UPLOAD_PATH = "C:/upload/";
    
    @GetMapping("/list")
    public String list(Model model) {
        log.info("custom list");
        try {
            List<WatchCustomVO> list = service.getList();
            model.addAttribute("list", list);
            log.info("Custom list size: " + list.size());
        } catch (Exception e) {
            log.error("Error loading custom list", e);
            model.addAttribute("list", new java.util.ArrayList<>());
            model.addAttribute("error", "게시글을 불러오는데 실패했습니다.");
        }
        return "custom/list";
    }
    
    @GetMapping("/get")
    public String get(@RequestParam("bno") Long bno, Model model) {
        log.info("custom get: " + bno);
        try {
            service.increaseViewCount(bno);
            WatchCustomVO custom = service.get(bno);
            if (custom != null) {
                model.addAttribute("custom", custom);
            } else {
                model.addAttribute("error", "게시글을 찾을 수 없습니다.");
                return "redirect:/custom/list";
            }
        } catch (Exception e) {
            log.error("Error getting custom post", e);
            model.addAttribute("error", "게시글을 불러오는데 실패했습니다.");
            return "redirect:/custom/list";
        }
        return "custom/get";
    }
    
    @GetMapping("/register")
    public String register() {
        log.info("custom register form");
        return "custom/register";
    }
    
    @PostMapping("/register")
    public String register(WatchCustomVO custom, 
                          @RequestParam(value = "file", required = false) MultipartFile file,
                          RedirectAttributes rttr) {
        log.info("custom register: " + custom);
        
        try {
            // 파일 업로드 처리
            if (file != null && !file.isEmpty()) {
                String uploadFolder = UPLOAD_PATH;
                File uploadPath = new File(uploadFolder);
                
                if (!uploadPath.exists()) {
                    uploadPath.mkdirs();
                    log.info("Upload directory created: " + uploadFolder);
                }
                
                String originalFilename = file.getOriginalFilename();
                String uuid = UUID.randomUUID().toString();
                String saveFilename = uuid + "_" + originalFilename;
                
                File saveFile = new File(uploadPath, saveFilename);
                file.transferTo(saveFile);
                
                String imageUrl = "/uploads/" + saveFilename;
                custom.setImageUrl(imageUrl);
                log.info("File uploaded: " + imageUrl);
            }
            
            // DB에 저장
            int result = service.register(custom);
            if (result > 0) {
                rttr.addFlashAttribute("result", "success");
                log.info("Custom registered successfully");
            } else {
                rttr.addFlashAttribute("result", "fail");
                log.error("Failed to register custom");
            }
            
        } catch (IOException e) {
            log.error("File upload error", e);
            rttr.addFlashAttribute("result", "file_error");
        } catch (Exception e) {
            log.error("Registration error", e);
            rttr.addFlashAttribute("result", "error");
        }
        
        return "redirect:/custom/list";
    }
    
    @GetMapping("/modify")
    public String modify(@RequestParam("bno") Long bno, Model model) {
        log.info("custom modify: " + bno);
        try {
            WatchCustomVO custom = service.get(bno);
            model.addAttribute("custom", custom);
        } catch (Exception e) {
            log.error("Error loading custom for modify", e);
            return "redirect:/custom/list";
        }
        return "custom/modify";
    }
    
    @PostMapping("/modify")
    public String modify(WatchCustomVO custom,
                        @RequestParam(value = "file", required = false) MultipartFile file,
                        @RequestParam(value = "existingImageUrl", required = false) String existingImageUrl,
                        RedirectAttributes rttr) {
        log.info("custom modify: " + custom);
        
        try {
            // 새 파일 업로드가 있는 경우
            if (file != null && !file.isEmpty()) {
                String uploadFolder = UPLOAD_PATH;
                File uploadPath = new File(uploadFolder);
                
                if (!uploadPath.exists()) {
                    uploadPath.mkdirs();
                }
                
                String originalFilename = file.getOriginalFilename();
                String uuid = UUID.randomUUID().toString();
                String saveFilename = uuid + "_" + originalFilename;
                
                File saveFile = new File(uploadPath, saveFilename);
                file.transferTo(saveFile);
                
                String imageUrl = "/uploads/" + saveFilename;
                custom.setImageUrl(imageUrl);
                log.info("New file uploaded: " + imageUrl);
            } else if (existingImageUrl != null && !existingImageUrl.isEmpty()) {
                // 새 파일이 없으면 기존 이미지 URL 유지
                custom.setImageUrl(existingImageUrl);
            }
            
            int result = service.modify(custom);
            if (result > 0) {
                rttr.addFlashAttribute("result", "success");
            }
        } catch (IOException e) {
            log.error("File upload error", e);
            rttr.addFlashAttribute("result", "file_error");
        } catch (Exception e) {
            log.error("Error modifying custom", e);
            rttr.addFlashAttribute("result", "error");
        }
        return "redirect:/custom/get?bno=" + custom.getBno();
    }
    
    @PostMapping("/remove")
    public String remove(@RequestParam("bno") Long bno, RedirectAttributes rttr) {
        log.info("custom remove: " + bno);
        try {
            int result = service.remove(bno);
            if (result > 0) {
                rttr.addFlashAttribute("result", "success");
            }
        } catch (Exception e) {
            log.error("Error removing custom", e);
            rttr.addFlashAttribute("result", "error");
        }
        return "redirect:/custom/list";
    }
    
    @PostMapping("/like")
    public ResponseEntity<Integer> like(@RequestParam("bno") Long bno, 
                                       @RequestParam("isLiked") boolean isLiked) {
        log.info("custom like: " + bno + ", isLiked: " + isLiked);
        try {
            if (isLiked) {
                service.decreaseLikeCount(bno);
            } else {
                service.increaseLikeCount(bno);
            }
            
            WatchCustomVO custom = service.get(bno);
            return new ResponseEntity<>(custom.getLikeCount(), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error handling like", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/listByDifficulty")
    public String getListByDifficulty(@RequestParam("difficulty") String difficulty, Model model) {
        log.info("custom listByDifficulty: " + difficulty);
        try {
            List<WatchCustomVO> list = service.getListByDifficulty(difficulty);
            model.addAttribute("list", list);
        } catch (Exception e) {
            log.error("Error loading custom list by difficulty", e);
            model.addAttribute("list", new java.util.ArrayList<>());
        }
        return "custom/list";
    }
}
