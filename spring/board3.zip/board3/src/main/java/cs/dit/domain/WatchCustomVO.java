package cs.dit.domain;

import java.util.Date;
import lombok.Data;

@Data
public class WatchCustomVO {
    private Long bno;
    private String title;
    private String projectName;
    private String style;
    private String movement;
    private String caseInfo;
    private String dialInfo;
    private String handsInfo;
    private int totalCost;
    private String difficulty;
    private String buildTime;
    private String imageUrl;
    private String content;
    private String writer;
    private int viewCount;
    private int likeCount;
    private int replyCount;
    private Date regdate;
    private Date updatedate;
}
