package cs.dit.domain;

import java.util.Date;
import lombok.Data;

@Data
public class ReplyVO {
    private Long rno;
    private String boardType;  // review, market, custom
    private Long bno;
    private String reply;
    private String replyer;
    private Long parentRno;    // 0이면 댓글, 0이 아니면 대댓글
    private Date replyDate;
    private Date updateDate;
}
