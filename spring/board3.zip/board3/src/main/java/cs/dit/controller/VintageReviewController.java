package cs.dit.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import cs.dit.domain.VintageReviewVO;
import cs.dit.service.VintageReviewService;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/review/*")
public class VintageReviewController {
    
    @Autowired
    private VintageReviewService service;
    
    // 전체 목록
    @GetMapping("/list")
    public void list(Model model) {
        log.info("Review List--------------------------");
        List<VintageReviewVO> list = service.getList();
        model.addAttribute("list", list);
    }
    
    // 테스트용 목록
    @GetMapping("/test")
    public void test(Model model) {
        log.info("Review Test--------------------------");
        List<VintageReviewVO> list = service.getList();
        log.info("List size: " + list.size());
        model.addAttribute("list", list);
    }
    
    // 브랜드별 목록
    @GetMapping("/listByBrand")
    public String listByBrand(@RequestParam("brand") String brand, Model model) {
        List<VintageReviewVO> list = service.getListByBrand(brand);
        model.addAttribute("list", list);
        model.addAttribute("filterType", "brand");
        model.addAttribute("filterValue", brand);
        return "/review/list";
    }
    
    // 평점별 목록
    @GetMapping("/listByRating")
    public String listByRating(@RequestParam("rating") int rating, Model model) {
        List<VintageReviewVO> list = service.getListByRating(rating);
        model.addAttribute("list", list);
        model.addAttribute("filterType", "rating");
        model.addAttribute("filterValue", rating);
        return "/review/list";
    }

    // 조회 (조회수 증가)
    @GetMapping({"/get", "/modify"})
    public void get(@RequestParam("bno") Long bno, Model model) {
        log.info("Review get--------------------------");
        
        // 조회수 증가
        service.increaseViewCount(bno);
        
        VintageReviewVO review = service.get(bno);
        model.addAttribute("review", review);
    }
    
    // 입력화면 출력
    @GetMapping("/register")
    public void register() {
        
    }
    
    // DB에 게시글 입력
    @PostMapping("/register")
    public String register(VintageReviewVO board, 
                          @RequestParam(value="file", required=false) MultipartFile imageFile,
                          RedirectAttributes rttr) {
        
        log.info("=== Review Register Start ===");
        log.info("imageFile: " + imageFile);
        
        // 파일 업로드 처리
        if (imageFile != null && !imageFile.isEmpty()) {
            try {
                log.info("File size: " + imageFile.getSize());
                log.info("File name: " + imageFile.getOriginalFilename());
                
                String uploadPath = "C:/upload/";
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) {
                    log.info("Creating upload directory: " + uploadPath);
                    uploadDir.mkdirs();
                }
                
                // 고유한 파일명 생성
                String originalFilename = imageFile.getOriginalFilename();
                String uuid = UUID.randomUUID().toString();
                String savedFilename = uuid + "_" + originalFilename;
                
                // 파일 저장
                File saveFile = new File(uploadPath + savedFilename);
                imageFile.transferTo(saveFile);
                
                // URL 설정
                board.setImageUrl("/controller/uploads/" + savedFilename);
                
                log.info("File uploaded successfully: " + savedFilename);
                log.info("File saved to: " + saveFile.getAbsolutePath());
                log.info("Image URL: " + board.getImageUrl());
            } catch (IOException e) {
                log.error("File upload failed", e);
            }
        } else {
            log.info("No file uploaded or file is empty");
        }
        
        int count = service.register(board);
        
        if(count == 1) {
            rttr.addFlashAttribute("result", "registered");
        }
    
        return "redirect:/review/list";
    }
    
    // 수정
    @PostMapping("/modify")
    public String modify(VintageReviewVO board,
                        @RequestParam(value = "file", required = false) MultipartFile file,
                        @RequestParam(value = "existingImageUrl", required = false) String existingImageUrl,
                        RedirectAttributes rttr) {
        log.info("Review modify------------------------------");
        
        try {
            // 새 파일 업로드가 있는 경우
            if (file != null && !file.isEmpty()) {
                String uploadFolder = "C:/upload/";
                File uploadPath = new File(uploadFolder);
                
                if (!uploadPath.exists()) {
                    uploadPath.mkdirs();
                }
                
                String originalFilename = file.getOriginalFilename();
                String uuid = UUID.randomUUID().toString();
                String saveFilename = uuid + "_" + originalFilename;
                
                File saveFile = new File(uploadPath, saveFilename);
                file.transferTo(saveFile);
                
                String imageUrl = "/controller/uploads/" + saveFilename;
                board.setImageUrl(imageUrl);
                log.info("New file uploaded: " + imageUrl);
            } else if (existingImageUrl != null && !existingImageUrl.isEmpty()) {
                // 새 파일이 없으면 기존 이미지 URL 유지
                board.setImageUrl(existingImageUrl);
            }
            
            int count = service.modify(board);
            
            if(count == 1)
                rttr.addFlashAttribute("result", "modified");
                
        } catch (IOException e) {
            log.error("File upload error", e);
            rttr.addFlashAttribute("result", "file_error");
        } catch (Exception e) {
            log.error("Error modifying review", e);
            rttr.addFlashAttribute("result", "error");
        }
        
        return "redirect:/review/list";
    }	
    
    // 삭제
    @PostMapping("/remove")
    public String remove(Long bno) {
        log.info("Review remove------------------------------");
        service.remove(bno);
        
        return "redirect:/review/list";
    }
    
    // 좋아요 토글 (AJAX)
    @PostMapping("/like")
    @ResponseBody
    public int toggleLike(@RequestParam("bno") Long bno, @RequestParam("isLiked") boolean isLiked) {
        if (isLiked) {
            // 좋아요 취소 (감소)
            service.decreaseLikeCount(bno);
        } else {
            // 좋아요 추가 (증가)
            service.increaseLikeCount(bno);
        }
        VintageReviewVO review = service.get(bno);
        return review.getLikeCount();
    }
}
