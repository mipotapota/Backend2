package cs.dit.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cs.dit.domain.VintageReviewVO;
import cs.dit.domain.VintageMarketVO;
import cs.dit.domain.WatchCustomVO;
import cs.dit.service.VintageReviewService;
import cs.dit.service.VintageMarketService;
import cs.dit.service.WatchCustomService;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	private VintageReviewService reviewService;
	
	@Autowired
	private VintageMarketService marketService;
	
	@Autowired
	private WatchCustomService customService;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {
		logger.info("Loading home page with all data...");
		
		try {
			// 1. �� �Խ��� �ֽ� 3�� �� ��ȸ
			List<VintageReviewVO> reviewList = reviewService.getList();
			List<VintageMarketVO> marketList = marketService.getList();
			List<WatchCustomVO> customList = customService.getList();
			
			// �ֽ� 3����
			if (reviewList.size() > 3) {
				reviewList = reviewList.subList(0, 3);
			}
			if (marketList.size() > 3) {
				marketList = marketList.subList(0, 3);
			}
			if (customList.size() > 3) {
				customList = customList.subList(0, 3);
			}
			
			// home.jsp���� ����ϴ� �̸����� ����
			model.addAttribute("recentReviews", reviewList);
			model.addAttribute("recentMarkets", marketList);
			model.addAttribute("recentCustoms", customList);
			
			// 2. �α� �Խñ� TOP 3 (��ȸ�� ����)
			List<Map<String, Object>> topPosts = new ArrayList<>();
			
			// ���� �Խñ� �߰�
			for (VintageReviewVO review : reviewService.getList()) {
				Map<String, Object> post = new HashMap<>();
				post.put("bno", review.getBno());
				post.put("title", review.getTitle());
				post.put("writer", review.getWriter());
				post.put("viewCount", review.getViewCount());
				post.put("likeCount", review.getLikeCount());
				post.put("replyCount", review.getReplyCount());
				post.put("boardType", "review");
				topPosts.add(post);
			}
			
			// �ŷ� �Խñ� �߰�
			for (VintageMarketVO market : marketService.getList()) {
				Map<String, Object> post = new HashMap<>();
				post.put("bno", market.getBno());
				post.put("title", market.getTitle());
				post.put("writer", market.getWriter());
				post.put("viewCount", market.getViewCount());
				post.put("likeCount", market.getLikeCount());
				post.put("replyCount", market.getReplyCount());
				post.put("boardType", "market");
				topPosts.add(post);
			}
			
			// Ŀ���� �Խñ� �߰�
			for (WatchCustomVO custom : customService.getList()) {
				Map<String, Object> post = new HashMap<>();
				post.put("bno", custom.getBno());
				post.put("title", custom.getTitle());
				post.put("writer", custom.getWriter());
				post.put("viewCount", custom.getViewCount());
				post.put("likeCount", custom.getLikeCount());
				post.put("replyCount", custom.getReplyCount());
				post.put("boardType", "custom");
				topPosts.add(post);
			}
			
			// ��ȸ�� ���� ���� �� TOP 3
			topPosts.sort((a, b) -> Integer.compare((Integer)b.get("viewCount"), (Integer)a.get("viewCount")));
			if (topPosts.size() > 3) {
				topPosts = topPosts.subList(0, 3);
			}
			model.addAttribute("topPosts", topPosts);
			
			logger.info("Home page loaded successfully");
			logger.info("Recent reviews: " + reviewList.size());
			logger.info("Recent markets: " + marketList.size());
			logger.info("Recent customs: " + customList.size());
			logger.info("Top posts: " + topPosts.size());
			
		} catch (Exception e) {
			logger.error("Error loading home page", e);
			// ���� �߻� �� �� ����Ʈ ����
			model.addAttribute("recentReviews", new ArrayList<>());
			model.addAttribute("recentMarkets", new ArrayList<>());
			model.addAttribute("recentCustoms", new ArrayList<>());
			model.addAttribute("topPosts", new ArrayList<>());
		}
		
		return "home";
	}
}