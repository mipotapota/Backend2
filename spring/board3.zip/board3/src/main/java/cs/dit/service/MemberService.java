package cs.dit.service;

import cs.dit.domain.MemberVO;

/**
 * ===================================
 * 회원 Service 인터페이스
 * ===================================
 * 작성자: GenCoder
 * 날짜: 2024-12-03
 * 설명: 회원 관련 비즈니스 로직
 * ===================================
 */
public interface MemberService {
    
    /**
     * 회원가입
     * @param member - 회원 정보
     * @return 성공 여부
     */
    public boolean register(MemberVO member);
    
    /**
     * 로그인
     * @param userid - 사용자 ID
     * @param userpw - 비밀번호
     * @return 회원 정보 (로그인 실패 시 null)
     */
    public MemberVO login(String userid, String userpw);
    
    /**
     * ID 중복 체크
     * @param userid - 사용자 ID
     * @return 중복 여부 (true: 중복, false: 사용 가능)
     */
    public boolean checkDuplicate(String userid);
}
