package cs.dit.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cs.dit.domain.ReplyVO;
import cs.dit.mapper.ReplyMapper;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class ReplyServiceImpl implements ReplyService {
    
    @Autowired
    private ReplyMapper mapper;
    
    @Override
    public List<ReplyVO> getList(String boardType, Long bno) {
        Map<String, Object> params = new HashMap<>();
        params.put("boardType", boardType);
        params.put("bno", bno);
        return mapper.getList(params);
    }
    
    @Override
    public ReplyVO get(Long rno) {
        return mapper.read(rno);
    }
    
    @Override
    public int register(ReplyVO reply) {
        return mapper.insert(reply);
    }
    
    @Override
    public int modify(ReplyVO reply) {
        return mapper.update(reply);
    }
    
    @Override
    public int remove(Long rno) {
        return mapper.delete(rno);
    }
    
    @Override
    public int getCount(String boardType, Long bno) {
        Map<String, Object> params = new HashMap<>();
        params.put("boardType", boardType);
        params.put("bno", bno);
        return mapper.getCount(params);
    }
}
