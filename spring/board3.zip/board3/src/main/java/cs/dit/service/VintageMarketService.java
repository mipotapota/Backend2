package cs.dit.service;

import java.util.List;
import cs.dit.domain.VintageMarketVO;

public interface VintageMarketService {
    public List<VintageMarketVO> getList();
    public List<VintageMarketVO> getListByTradeType(String tradeType);
    public List<VintageMarketVO> getListByBrand(String brand);
    public List<VintageMarketVO> getListByStatus(String tradeStatus);
    public VintageMarketVO get(Long bno);
    public int register(VintageMarketVO board);
    public int modify(VintageMarketVO board);
    public int remove(Long bno);
    public void increaseViewCount(Long bno);
    public void increaseLikeCount(Long bno);
    public void decreaseLikeCount(Long bno);
}
