package cs.dit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cs.dit.domain.MemberVO;
import cs.dit.mapper.MemberMapper;
import lombok.extern.slf4j.Slf4j;

/**
 * ===================================
 * 회원 Service 구현체
 * ===================================
 * 작성자: GenCoder
 * 날짜: 2024-12-03
 * 설명: 회원 관련 비즈니스 로직 구현
 * ===================================
 */
@Slf4j
@Service
public class MemberServiceImpl implements MemberService {
    
    @Autowired
    private MemberMapper mapper;
    
    /**
     * 회원가입
     */
    @Override
    public boolean register(MemberVO member) {
        log.info("회원가입: " + member.getUserid());
        
        // ID 중복 체크
        if (mapper.checkId(member.getUserid()) > 0) {
            log.warn("이미 존재하는 ID: " + member.getUserid());
            return false;
        }
        
        // 회원 정보 저장
        int result = mapper.insert(member);
        return result == 1;
    }
    
    /**
     * 로그인
     */
    @Override
    public MemberVO login(String userid, String userpw) {
        log.info("로그인 시도: " + userid);
        
        // ID로 회원 조회
        MemberVO member = mapper.read(userid);
        
        // 회원이 없거나 비밀번호가 틀리면 null 반환
        if (member == null) {
            log.warn("존재하지 않는 ID: " + userid);
            return null;
        }
        
        if (!member.getUserpw().equals(userpw)) {
            log.warn("비밀번호 불일치: " + userid);
            return null;
        }
        
        log.info("로그인 성공: " + userid);
        return member;
    }
    
    /**
     * ID 중복 체크
     */
    @Override
    public boolean checkDuplicate(String userid) {
        int count = mapper.checkId(userid);
        return count > 0;
    }
}
