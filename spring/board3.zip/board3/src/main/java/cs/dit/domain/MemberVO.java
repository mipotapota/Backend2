package cs.dit.domain;

import java.util.Date;
import lombok.Data;

/**
 * ===================================
 * 회원 정보 VO (Value Object)
 * ===================================
 * 작성자: GenCoder
 * 날짜: 2024-12-03
 * 설명: 회원 정보를 담는 데이터 객체
 * ===================================
 */
@Data
public class MemberVO {
    
    // 사용자 ID (Primary Key)
    private String userid;
    
    // 비밀번호
    private String userpw;
    
    // 사용자 이름
    private String username;
    
    // 가입 날짜
    private Date regdate;
}
