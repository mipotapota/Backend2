package cs.dit.mapper;

import cs.dit.domain.MemberVO;

/**
 * ===================================
 * 회원 Mapper 인터페이스
 * ===================================
 * 작성자: GenCoder
 * 날짜: 2024-12-03
 * 설명: 회원 관련 데이터베이스 작업
 * ===================================
 */
public interface MemberMapper {
    
    /**
     * 회원가입
     * @param member - 회원 정보
     * @return 삽입된 행 수
     */
    public int insert(MemberVO member);
    
    /**
     * 로그인 (ID로 회원 조회)
     * @param userid - 사용자 ID
     * @return 회원 정보
     */
    public MemberVO read(String userid);
    
    /**
     * ID 중복 체크
     * @param userid - 사용자 ID
     * @return 존재 여부 (1: 존재, 0: 없음)
     */
    public int checkId(String userid);
}
