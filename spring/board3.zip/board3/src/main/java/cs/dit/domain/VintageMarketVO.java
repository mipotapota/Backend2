package cs.dit.domain;

import java.util.Date;
import lombok.Data;

@Data
public class VintageMarketVO {
    private Long bno;
    private String title;
    private String tradeType;
    private String brand;
    private String model;
    private String year;
    private int price;
    private String watchCondition;
    private String isServiced;
    private String location;
    private String tradeStatus;
    private String imageUrl;
    private String content;
    private String writer;
    private int viewCount;
    private int likeCount;
    private int replyCount;
    private Date regdate;
    private Date updatedate;
}
