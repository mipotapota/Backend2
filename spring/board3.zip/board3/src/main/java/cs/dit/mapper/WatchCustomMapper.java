package cs.dit.mapper;

import java.util.List;
import cs.dit.domain.WatchCustomVO;

public interface WatchCustomMapper {
    int insert(WatchCustomVO custom);
    WatchCustomVO read(Long bno);
    int update(WatchCustomVO custom);
    int delete(Long bno);
    List<WatchCustomVO> getList();
    List<WatchCustomVO> getListByDifficulty(String difficulty);
    void increaseViewCount(Long bno);
    void increaseLikeCount(Long bno);
    void decreaseLikeCount(Long bno);
}
