package cs.dit.domain;

import java.util.Date;
import lombok.Data;

@Data
public class VintageReviewVO {
    private Long bno;
    private String title;
    private String brand;
    private String model;
    private String year;
    private String movement;
    private int rating;
    private int price;
    private String watchCondition;
    private String imageUrl;
    private String content;
    private String writer;
    private int viewCount;
    private int likeCount;
    private int replyCount;
    private Date regdate;
    private Date updatedate;
}
