package cs.dit.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cs.dit.domain.WatchCustomVO;
import cs.dit.mapper.WatchCustomMapper;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class WatchCustomServiceImpl implements WatchCustomService {
    
    @Autowired
    private WatchCustomMapper mapper;
    
    @Override
    public int register(WatchCustomVO custom) {
        log.info("register custom: " + custom);
        return mapper.insert(custom);
    }
    
    @Override
    public WatchCustomVO get(Long bno) {
        log.info("get custom: " + bno);
        return mapper.read(bno);
    }
    
    @Override
    public int modify(WatchCustomVO custom) {
        log.info("modify custom: " + custom);
        return mapper.update(custom);
    }
    
    @Override
    public int remove(Long bno) {
        log.info("remove custom: " + bno);
        return mapper.delete(bno);
    }
    
    @Override
    public List<WatchCustomVO> getList() {
        log.info("getList custom");
        return mapper.getList();
    }
    
    @Override
    public List<WatchCustomVO> getListByDifficulty(String difficulty) {
        log.info("getListByDifficulty: " + difficulty);
        return mapper.getListByDifficulty(difficulty);
    }
    
    @Override
    public void increaseViewCount(Long bno) {
        mapper.increaseViewCount(bno);
    }
    
    @Override
    public void increaseLikeCount(Long bno) {
        mapper.increaseLikeCount(bno);
    }
    
    @Override
    public void decreaseLikeCount(Long bno) {
        mapper.decreaseLikeCount(bno);
    }
}
