package cs.dit.service;

import java.util.List;
import cs.dit.domain.WatchCustomVO;

public interface WatchCustomService {
    int register(WatchCustomVO custom);
    WatchCustomVO get(Long bno);
    int modify(WatchCustomVO custom);
    int remove(Long bno);
    List<WatchCustomVO> getList();
    List<WatchCustomVO> getListByDifficulty(String difficulty);
    void increaseViewCount(Long bno);
    void increaseLikeCount(Long bno);
    void decreaseLikeCount(Long bno);
}
