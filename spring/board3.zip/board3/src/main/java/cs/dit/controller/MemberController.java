package cs.dit.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import cs.dit.domain.MemberVO;
import cs.dit.service.MemberService;
import lombok.extern.slf4j.Slf4j;

/**
 * ===================================
 * 회원 Controller
 * ===================================
 * 작성자: GenCoder
 * 날짜: 2024-12-03
 * 설명: 회원가입, 로그인, 로그아웃 처리
 * ===================================
 */
@Slf4j
@Controller
@RequestMapping("/member")
public class MemberController {
    
    @Autowired
    private MemberService service;
    
    /**
     * 회원가입 페이지
     */
    @GetMapping("/register")
    public void registerForm() {
        log.info("회원가입 페이지");
    }
    
    /**
     * 회원가입 처리
     */
    @PostMapping("/register")
    public String register(MemberVO member, RedirectAttributes rttr) {
        log.info("회원가입 처리: " + member);
        
        boolean success = service.register(member);
        
        if (success) {
            rttr.addFlashAttribute("result", "registered");
            return "redirect:/member/login";
        } else {
            rttr.addFlashAttribute("error", "이미 존재하는 아이디입니다.");
            return "redirect:/member/register";
        }
    }
    
    /**
     * ID 중복 체크 (AJAX)
     */
    @PostMapping("/checkId")
    @ResponseBody
    public String checkId(@RequestParam("userid") String userid) {
        boolean isDuplicate = service.checkDuplicate(userid);
        return isDuplicate ? "duplicate" : "available";
    }
    
    /**
     * 로그인 페이지
     */
    @GetMapping("/login")
    public void loginForm() {
        log.info("로그인 페이지");
    }
    
    /**
     * 로그인 처리
     */
    @PostMapping("/login")
    public String login(@RequestParam("userid") String userid,
                       @RequestParam("userpw") String userpw,
                       HttpSession session,
                       RedirectAttributes rttr) {
        log.info("로그인 시도: " + userid);
        
        MemberVO member = service.login(userid, userpw);
        
        if (member != null) {
            // 로그인 성공 - 세션에 사용자 정보 저장
            session.setAttribute("loginUser", member);
            log.info("로그인 성공: " + member.getUsername());
            return "redirect:/";
        } else {
            // 로그인 실패
            rttr.addFlashAttribute("error", "아이디 또는 비밀번호가 올바르지 않습니다.");
            return "redirect:/member/login";
        }
    }
    
    /**
     * 로그아웃
     */
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        log.info("로그아웃");
        session.invalidate();
        return "redirect:/";
    }
}
