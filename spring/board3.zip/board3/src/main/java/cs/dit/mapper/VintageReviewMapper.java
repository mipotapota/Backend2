package cs.dit.mapper;

import java.util.List;
import cs.dit.domain.VintageReviewVO;

public interface VintageReviewMapper {
    // 전체 목록
    public List<VintageReviewVO> getList();
    
    // 검색/필터
    public List<VintageReviewVO> getListByBrand(String brand);
    public List<VintageReviewVO> getListByRating(int rating);
    
    // 조회
    public VintageReviewVO read(Long bno);
    
    // 등록
    public int insert(VintageReviewVO board);
    
    // 수정
    public int update(VintageReviewVO board);
    
    // 삭제
    public int delete(Long bno);
    
    // 조회수 증가
    public void increaseViewCount(Long bno);
    
    // 좋아요 증가/감소
    public void increaseLikeCount(Long bno);
    public void decreaseLikeCount(Long bno);
    
    // 댓글 수 업데이트
    public void updateReplyCount(Long bno);
}
