package cs.dit.service;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cs.dit.domain.BoardVO;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardServiceTests {
	
	@Autowired
	private BoardService service;

	@Test
	public void testGetList() {
		log.info("GetList---------------------------");
		
		List<BoardVO> list = service.getList();
		//service.getList().forEach(board-> log.info(board)); 			
		
		for(BoardVO board : list) {
			log.info(board);
		}
	}
	
	@Test
	public void testGet() {
		log.info("GET---------------------------");
		
		BoardVO board = service.get(3L);
		log.info(board);
	}

	@Test
	public void testRegister() {
		BoardVO vo = new BoardVO();
		vo.setBno(2L);
		vo.setTitle("안녕!");
		vo.setContent("잘 있었어요?");
		vo.setWriter("홍길동");
		service.register(vo);
	}
	
	@Test
	public void testModify() {
		log.info("Modify---------------------------");
		BoardVO board = service.get(6L);
		
		board.setContent("진짜 졸린다!!!!");
		log.info("Modify result : " + service.modify(board));
	}
	
	@Test
	public void testRemove() {
		log.info("Remove---------------------------");
		
		log.info("remove result : " + service.remove(4L));
	}
	
}
